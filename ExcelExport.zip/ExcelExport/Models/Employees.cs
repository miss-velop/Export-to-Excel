﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelExport.Models
{
    public class Employees
    {
        public int EmployeeID { get; set; }
        public string name { get; set; }
        public string role { get; set; }
    }
}
