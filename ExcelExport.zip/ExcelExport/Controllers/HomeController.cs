﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Office2010.ExcelAc;
using ExcelExport.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelExport.Controllers
{
    public class HomeController : Controller
    {
        List<Employees> _employees = new List<Employees>();

        public HomeController()
        {
           for (int i =1; i<=20;i++)
            {
                _employees.Add(new Employees()
                {
                    EmployeeID = i,
                    name = "name" + i,
                    role = "software Eng L1"

                });
            }
        }

        public IActionResult Index()
        {
          using (var workbook=new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Employees");
                var currentRow = 1;
                worksheet.Cell(currentRow, 1).Value = "EmployeeID";
                worksheet.Cell(currentRow, 2).Value = "Name";
                worksheet.Cell(currentRow, 3).Value = "Role";

                foreach(var employee in _employees)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = employee.EmployeeID;
                    worksheet.Cell(currentRow, 2).Value = employee.name;
                    worksheet.Cell(currentRow, 3).Value = employee.role;

                }
                using(var stream =new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();
                    return File(content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "Employees.xlsx");
                }
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }


    }
}
